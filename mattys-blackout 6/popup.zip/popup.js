// Matty’s Blackout Popup – v10.1 (Dark Mode + Independent Toggles)
document.addEventListener("DOMContentLoaded", () => {
  const toggles = [
    "darkModeToggle",
    "splitViewToggle",
    "contactToPropertyToggle",
    "propertyToContactToggle"
  ];

  chrome.storage.local.get(toggles, (result) => {
    toggles.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.checked = result[id] || false;
    });

    if (result.darkModeToggle) document.body.classList.add("dark-mode");
    detectActiveSplitView();
  });

  toggles.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;

    el.addEventListener("change", () => {
      const val = el.checked;
      chrome.storage.local.set({ [id]: val });

      if (id === "contactToPropertyToggle" && val)
        chrome.storage.local.set({ propertyToContactToggle: false });
      if (id === "propertyToContactToggle" && val)
        chrome.storage.local.set({ contactToPropertyToggle: false });

      const map = {
        darkModeToggle: "darkMode",
        splitViewToggle: "splitView",
        contactToPropertyToggle: "contactToProperty",
        propertyToContactToggle: "propertyToContact"
      };

      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (!tabs.length || !tabs[0].id) return;
        const url = tabs[0].url || '';
        if (url.startsWith('chrome://') || url.startsWith('edge://') || url.startsWith('about:')) return;

        chrome.tabs.sendMessage(
          tabs[0].id,
          { action: map[id], state: val },
          () => { if (chrome.runtime.lastError) return; }
        );
      });

      if (id === "darkModeToggle") {
        document.body.classList.toggle("dark-mode", val);
      }

      const indicator = document.getElementById("splitIndicator");
      if (id === "splitViewToggle") {
        indicator.classList.toggle("split-active", val);
      }
    });
  });
});

function detectActiveSplitView() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs.length || !tabs[0].id) return;
    const url = tabs[0].url || '';
    if (url.startsWith('chrome://') || url.startsWith('edge://') || url.startsWith('about:')) return;

    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => window.name === "RNX_LEFT" || window.name === "RNX_RIGHT"
    }, (res) => {
      if (chrome.runtime.lastError || !res || !res[0]) return;

      const splitToggle = document.getElementById("splitViewToggle");
      const indicator = document.getElementById("splitIndicator");
      if (res[0].result) {
        splitToggle.checked = true;
        indicator.classList.add("split-active");
        chrome.storage.local.set({ splitViewToggle: true });
      } else {
        indicator.classList.remove("split-active");
      }
    });
  });
}
