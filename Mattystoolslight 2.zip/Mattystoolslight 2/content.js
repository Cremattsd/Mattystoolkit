console.log("Matty’s Toolkit Light Content Loaded");

const ORIGIN = location.origin;
const KEY_RE = /#key=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

let splitEnabled = false;
let contactToProperty = false;
let propertyToContact = false;

// Load saved toggles
chrome.storage.local.get(
  ["splitViewToggle", "contactToPropertyToggle", "propertyToContactToggle"],
  (r) => {
    splitEnabled = !!r.splitViewToggle;
    contactToProperty = !!r.contactToPropertyToggle;
    propertyToContact = !!r.propertyToContactToggle;

    if (splitEnabled) initSplitRouting();
  }
);

// Listen for popup updates
chrome.runtime.onMessage.addListener((msg) => {
  switch (msg.action) {
    case "splitViewToggle":
      splitEnabled = msg.state;
      break;

    case "contactToPropertyToggle":
      contactToProperty = msg.state;
      propertyToContact = false;
      break;

    case "propertyToContactToggle":
      propertyToContact = msg.state;
      contactToProperty = false;
      break;
  }
});


// ======================================================
// MAIN CLICK ROUTING (fixed target="_blank" bug)
// ======================================================
function initSplitRouting() {
  document.addEventListener("click", (e) => {
    if (!splitEnabled) return;

    const link = e.target.closest("a[href]");
    if (!link) return;

    const href = link.href;
    if (!href) return;

    // ------------------------------------------------------------------
    // 🔥 FIX: RealNex property → contact always uses target="_blank"
    // We MUST override this or routing will never fire.
    // ------------------------------------------------------------------
    if (propertyToContact && isContact(href)) {
      e.preventDefault();
      link.removeAttribute("target"); // stop new-tab behavior
      chrome.runtime.sendMessage({ route: "contact", url: href });
      return;
    }

    // CONTACT → PROPERTY (already working)
    if (contactToProperty && isProperty(href)) {
      e.preventDefault();
      chrome.runtime.sendMessage({ route: "property", url: href });
      return;
    }

  }, true);
}


// ======================================================
// HELPERS
// ======================================================
function isProperty(url) {
  return url.includes("/property") && KEY_RE.test(url);
}

function isContact(url) {
  return url.includes("/contact") && KEY_RE.test(url);
}
