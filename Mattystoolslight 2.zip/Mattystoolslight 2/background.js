console.log("Matty’s Toolkit Light Background Loaded");

let leftTabId = null;   // contacts
let rightTabId = null;  // properties

const KEY_RE = /#key=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

let lastLeftKey = null;
let lastRightKey = null;

// ===============================================================
// FORCE-RELOAD QUERYSTRING (fixes RealNex not refreshing on hash change)
// ===============================================================
function withReload(url) {
  try {
    const u = new URL(url);
    u.searchParams.set("mbReload", Date.now());
    return u.toString();
  } catch {
    return url;
  }
}

// ===============================================================
// MESSAGE LISTENER
// ===============================================================
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.route === "property") return routeProperty(msg.url);
  if (msg.route === "contact") return routeContact(msg.url);
});

// ===============================================================
// PROPERTY TAB
// ===============================================================
function routeProperty(url) {
  const refreshed = withReload(url);
  const key = refreshed.match(KEY_RE)?.[0];

  if (key && key === lastRightKey) return;  // skip duplicates
  lastRightKey = key;

  if (rightTabId) {
    chrome.tabs.update(rightTabId, { url: refreshed, active: false }, tab => {
      if (chrome.runtime.lastError || !tab) {
        rightTabId = null;
        routeProperty(refreshed);
      }
    });
    return;
  }

  chrome.tabs.create({ url: refreshed, active: false }, tab => {
    rightTabId = tab.id;
  });
}

// ===============================================================
// CONTACT TAB
// ===============================================================
function routeContact(url) {
  const refreshed = withReload(url);
  const key = refreshed.match(KEY_RE)?.[0];

  if (key && key === lastLeftKey) return; // skip duplicates
  lastLeftKey = key;

  if (leftTabId) {
    chrome.tabs.update(leftTabId, { url: refreshed, active: false }, tab => {
      if (chrome.runtime.lastError || !tab) {
        leftTabId = null;
        routeContact(refreshed);
      }
    });
    return;
  }

  chrome.tabs.create({ url: refreshed, active: false }, tab => {
    leftTabId = tab.id;
  });
}

// ===============================================================
// CLEANUP WHEN USER CLOSES A TAB
// ===============================================================
chrome.tabs.onRemoved.addListener((id) => {
  if (id === leftTabId) {
    leftTabId = null;
    lastLeftKey = null;
  }
  if (id === rightTabId) {
    rightTabId = null;
    lastRightKey = null;
  }
});
