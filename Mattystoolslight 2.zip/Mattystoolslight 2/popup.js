document.addEventListener("DOMContentLoaded", () => {

  const toggles = [
    "splitViewToggle",
    "contactToPropertyToggle",
    "propertyToContactToggle"
  ];

  chrome.storage.local.get(toggles, (res) => {
    toggles.forEach(id => {
      const el = document.getElementById(id);
      el.checked = !!res[id];
    });
  });

  // Split View main toggle
  document.getElementById("splitViewToggle")
    .addEventListener("change", e => {
      chrome.storage.local.set({ splitViewToggle: e.target.checked });
      chrome.runtime.sendMessage({ action: "splitViewToggle", state: e.target.checked });
    });

  // Contacts → Properties
  document.getElementById("contactToPropertyToggle")
    .addEventListener("change", e => {
      const state = e.target.checked;

      // block reverse toggle
      if (state) {
        document.getElementById("propertyToContactToggle").checked = false;
        chrome.storage.local.set({ propertyToContactToggle: false });
      }

      chrome.storage.local.set({ contactToPropertyToggle: state });
      chrome.runtime.sendMessage({ action: "contactToPropertyToggle", state });
    });

  // Properties → Contacts
  document.getElementById("propertyToContactToggle")
    .addEventListener("change", e => {
      const state = e.target.checked;

      if (state) {
        document.getElementById("contactToPropertyToggle").checked = false;
        chrome.storage.local.set({ contactToPropertyToggle: false });
      }

      chrome.storage.local.set({ propertyToContactToggle: state });
      chrome.runtime.sendMessage({ action: "propertyToContactToggle", state });
    });

});
